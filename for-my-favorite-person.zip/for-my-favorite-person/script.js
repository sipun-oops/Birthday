/* ==========================================================================
   FOR MY FAVORITE PERSON — script.js
   Pure vanilla JS. No frameworks, no build step.

   HOW TO CUSTOMISE
   ----------------
   Everything you are likely to want to change lives in the CONFIG object
   right below this comment:
     - name          → her name (used in a couple of alt texts)
     - usPhotos      → filenames inside images/us/      (Screen 3 slideshow)
     - herPhotos     → filenames inside images/her/      (Screen 4 gallery)
     - song          → title shown on the music player + the mp3 filename
     - wishes        → the 12 birthday messages (Screen 5)
   Missing images/audio fail gracefully with an elegant placeholder, so you
   can preview the whole site before dropping your real files in.
   ========================================================================== */

const CONFIG = {
  // CHANGE HER NAME HERE
  name: "My Love",

  // CHANGE / ADD PHOTOS HERE — just list the filenames that live in images/us/
  usPhotos: ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg"],

  // CHANGE / ADD PHOTOS HERE — just list the filenames that live in images/her/
  herPhotos: ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg"],

  // CHANGE THE SONG — replace music/song.mp3 with your file (keep the filename)
  // and edit the title below to match.
  song: {
    title: "Our Song",
  },

  // CHANGE THE LOVE LETTER / WISHES HERE — one entry per card.
  // Use \n for a line break inside a card.
  wishes: [
    "Happy Birthday, My Love.",
    "Today isn't just another day...\nToday is the day the most beautiful person came into this world.",
    "Thank you for filling my life with happiness, laughter, and countless beautiful memories.",
    "Every moment spent with you has become one of my favorite memories.",
    "Your smile has a way of making every bad day disappear.",
    "No matter what happens in life, I'll always pray for your happiness.",
    "May this birthday bring you endless happiness, success, peace, and everything your heart wishes for.",
    "I hope this year gives you a thousand new reasons to smile.",
    "Thank you for being my safe place, my happiness, and my favorite person.",
    "I may not always find the perfect words, but my heart will always choose you.",
    "Promise me you'll keep smiling... because your smile is my favorite view.",
    "Happy Birthday, My Love ❤️\nI Love You Today.\nI Love You Tomorrow.\nI Love You Forever.\n🎂❤️",
  ],
};

/* ==========================================================================
   SMALL HELPERS
   ========================================================================== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

/** Builds an <img> that swaps itself for an elegant placeholder on error. */
function buildImage(src, altText, placeholderLabel) {
  const wrap = document.createElement("div");
  wrap.className = "media-wrap";
  wrap.style.width = "100%";
  wrap.style.height = "100%";

  const img = document.createElement("img");
  img.loading = "lazy";
  img.alt = altText;
  img.src = src;
  img.dataset.loaded = "false";

  img.addEventListener("load", () => {
    img.dataset.loaded = "true";
  });
  img.addEventListener("error", () => {
    wrap.innerHTML = `
      <div class="placeholder">
        <span class="ph-icon">🤍</span>
        <span>${placeholderLabel}</span>
      </div>`;
  });

  wrap.appendChild(img);
  return wrap;
}

/* ==========================================================================
   AMBIENT PARTICLES — floating hearts + sparkles, running everywhere
   ========================================================================== */
const heartsLayer = $("#floatingHearts");
const sparkLayer = $("#sparkles");
const heartGlyphs = ["❤", "❤︎", "💗", "💕"];

function spawnHeart(boost = false) {
  const h = document.createElement("span");
  h.className = "f-heart";
  h.textContent = heartGlyphs[Math.floor(Math.random() * heartGlyphs.length)];
  const left = Math.random() * 100;
  const duration = 7 + Math.random() * 6;
  const size = 12 + Math.random() * (boost ? 18 : 12);
  h.style.left = left + "%";
  h.style.fontSize = size + "px";
  h.style.setProperty("--drift", (Math.random() * 60 - 30) + "px");
  h.style.animationDuration = duration + "s";
  heartsLayer.appendChild(h);
  setTimeout(() => h.remove(), duration * 1000 + 200);
}

function spawnSpark() {
  const s = document.createElement("span");
  s.className = "spark";
  s.style.left = Math.random() * 100 + "%";
  s.style.top = Math.random() * 100 + "%";
  s.style.animationDelay = Math.random() * 2 + "s";
  sparkLayer.appendChild(s);
  setTimeout(() => s.remove(), 3200);
}

setInterval(() => spawnHeart(false), 1400);
setInterval(spawnSpark, 500);

/** Temporary denser burst — used on the final wish card and the cake reveal */
function heartBurst(count = 18) {
  for (let i = 0; i < count; i++) {
    setTimeout(() => spawnHeart(true), i * 90);
  }
}

/* ==========================================================================
   CONFETTI — a tiny reusable canvas particle system
   ========================================================================== */
function spawnConfetti(canvas, duration = 3200) {
  const ctx = canvas.getContext("2d");
  const parent = canvas.parentElement;
  const w = (canvas.width = parent.clientWidth);
  const h = (canvas.height = parent.clientHeight);

  const colors = ["#eaa8c4", "#dcb571", "#f3d199", "#cf6f97", "#ffffff"];
  const pieces = Array.from({ length: 90 }, () => ({
    x: Math.random() * w,
    y: -20 - Math.random() * h * 0.5,
    vx: (Math.random() - 0.5) * 2.2,
    vy: 2 + Math.random() * 3,
    size: 5 + Math.random() * 6,
    color: colors[Math.floor(Math.random() * colors.length)],
    rot: Math.random() * 360,
    rotSpeed: (Math.random() - 0.5) * 10,
    shape: Math.random() > 0.5 ? "rect" : "circle",
  }));

  const start = performance.now();
  function frame(now) {
    const elapsed = now - start;
    ctx.clearRect(0, 0, w, h);
    pieces.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.rotSpeed;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rot * Math.PI) / 180);
      ctx.fillStyle = p.color;
      if (p.shape === "rect") {
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.size / 2.4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });
    if (elapsed < duration) {
      requestAnimationFrame(frame);
    } else {
      ctx.clearRect(0, 0, w, h);
    }
  }
  requestAnimationFrame(frame);
}

function spawnBalloons(container, count = 8) {
  const colors = [
    "linear-gradient(160deg,#f3b6c9,#d9789e)",
    "linear-gradient(160deg,#f7cfa1,#e3a86c)",
    "linear-gradient(160deg,#c8a4e0,#9a6bc4)",
    "linear-gradient(160deg,#a8d8e0,#6bb4c4)",
  ];
  for (let i = 0; i < count; i++) {
    setTimeout(() => {
      const b = document.createElement("div");
      b.className = "balloon";
      b.style.left = Math.random() * 85 + "%";
      b.style.background = colors[Math.floor(Math.random() * colors.length)];
      b.style.setProperty("--sway", Math.random() * 60 - 30 + "px");
      b.style.animationDuration = 5 + Math.random() * 3 + "s";
      container.appendChild(b);
      b.addEventListener("animationend", () => b.remove());
    }, i * 220);
  }
}

/* ==========================================================================
   SCREEN CONTROLLER
   ========================================================================== */
const screens = $$(".screen");
let currentScreenId = "screen-loading";

const enterHandlers = {};
const leaveHandlers = {};

function showScreen(id) {
  const prev = currentScreenId;
  if (leaveHandlers[prev]) leaveHandlers[prev]();

  screens.forEach((s) => s.classList.remove("active"));
  const target = document.getElementById(id);
  target.classList.add("active");
  currentScreenId = id;

  if (enterHandlers[id]) enterHandlers[id]();
}

/* ==========================================================================
   SCREEN 1 — LOADING
   ========================================================================== */
function initLoading() {
  setTimeout(() => {
    $("#loadingTitle").classList.add("show");
  }, 1600);
  setTimeout(() => {
    $("#btnBegin").classList.add("show");
    $(".hint-text").classList.add("show");
  }, 2500);
}
initLoading();

const bgMusic = $("#bgMusic");
const musicPlayer = $("#musicPlayer");

$("#btnBegin").addEventListener("click", () => {
  bgMusic.volume = 0.7;
  bgMusic.play().catch(() => {
    /* Autoplay/decoding may fail until a real music/song.mp3 is added — silent by design */
  });
  musicPlayer.classList.remove("hidden");
  showScreen("screen-envelope");
});

/* ==========================================================================
   SCREEN 2 — ENVELOPE
   ========================================================================== */
const envelope = $("#envelope");
envelope.addEventListener("click", () => {
  if (envelope.classList.contains("open")) return;
  envelope.classList.add("open");
  $("#envelopeHint").style.opacity = "0";
});

$("#btnOpenCard").addEventListener("click", (e) => {
  e.stopPropagation();
  showScreen("screen-slideshow");
});

/* ==========================================================================
   SCREEN 3 — SLIDESHOW ("Us")
   ========================================================================== */
let slideshowBuilt = false;
let slideIndex = 0;
let slideTimer = null;

function buildSlideshow() {
  const stage = $("#slideshowStage");
  const dots = $("#slideDots");
  stage.innerHTML = "";
  dots.innerHTML = "";

  CONFIG.usPhotos.forEach((file, i) => {
    const slide = document.createElement("div");
    slide.className = "slide";
    const media = buildImage(
      `images/us/${file}`,
      `A moment with ${CONFIG.name}`,
      `Add images/us/${file}`
    );
    slide.appendChild(media);
    stage.appendChild(slide);

    const dot = document.createElement("span");
    dots.appendChild(dot);
  });

  slideshowBuilt = true;
  activateSlide(0);
}

function activateSlide(i) {
  const slides = $$(".slide", $("#slideshowStage"));
  const dots = $$("#slideDots span");
  if (!slides.length) return;
  slideIndex = (i + slides.length) % slides.length;

  slides.forEach((s, idx) => s.classList.toggle("active", idx === slideIndex));
  dots.forEach((d, idx) => d.classList.toggle("active", idx === slideIndex));

  // restart the ken-burns zoom for the newly active slide
  const media = slides[slideIndex].querySelector("img, .placeholder");
  if (media) {
    media.style.animation = "none";
    void media.offsetWidth;
    media.style.animation = "";
  }
}

function startSlideAutoplay() {
  clearInterval(slideTimer);
  slideTimer = setInterval(() => activateSlide(slideIndex + 1), 5000);
}

enterHandlers["screen-slideshow"] = () => {
  if (!slideshowBuilt) buildSlideshow();
  startSlideAutoplay();
};
leaveHandlers["screen-slideshow"] = () => clearInterval(slideTimer);

// swipe left / right
(function attachSlideshowSwipe() {
  const stage = $("#screen-slideshow");
  let startX = 0;
  let startY = 0;
  stage.addEventListener("touchstart", (e) => {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });
  stage.addEventListener("touchend", (e) => {
    const dx = e.changedTouches[0].clientX - startX;
    const dy = e.changedTouches[0].clientY - startY;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) {
      activateSlide(slideIndex + (dx < 0 ? 1 : -1));
      startSlideAutoplay();
    }
  }, { passive: true });
})();

$("#btnToGallery").addEventListener("click", () => showScreen("screen-gallery"));

/* ==========================================================================
   SCREEN 4 — GALLERY ("My Favourite Girl")
   ========================================================================== */
let galleryBuilt = false;

function buildGallery() {
  const grid = $("#galleryGrid");
  grid.innerHTML = "";
  CONFIG.herPhotos.forEach((file) => {
    const card = document.createElement("div");
    card.className = "gal-card";
    const src = `images/her/${file}`;
    const media = buildImage(src, CONFIG.name, `Add images/her/${file}`);
    card.appendChild(media);
    card.addEventListener("click", () => {
      const img = card.querySelector("img");
      if (img && img.dataset.loaded === "true") openLightbox(src);
    });
    grid.appendChild(card);
  });
  galleryBuilt = true;
}
enterHandlers["screen-gallery"] = () => {
  if (!galleryBuilt) buildGallery();
};

const lightbox = $("#lightbox");
const lightboxImg = $("#lightboxImg");
function openLightbox(src) {
  lightboxImg.src = src;
  lightbox.classList.add("show");
}
$("#lightboxClose").addEventListener("click", () => lightbox.classList.remove("show"));
lightbox.addEventListener("click", (e) => {
  if (e.target === lightbox) lightbox.classList.remove("show");
});

$("#btnToWishes").addEventListener("click", () => showScreen("screen-wishes"));

/* ==========================================================================
   SCREEN 5 — WISHES
   ========================================================================== */
let wishIndex = 0;
let wishBusy = false;
const wishCard = $("#wishCard");
const wishTextEl = $("#wishText");
const wishProgressEl = $("#wishProgress");
const btnNextWish = $("#btnNextWish");
const btnFinalSurprise = $("#btnFinalSurprise");

function typeText(el, text, speed = 26) {
  return new Promise((resolve) => {
    el.innerHTML = "";
    const cursor = document.createElement("span");
    cursor.className = "cursor";
    el.appendChild(cursor);
    let i = 0;
    function step() {
      if (i < text.length) {
        const ch = text[i];
        if (ch === "\n") {
          el.insertBefore(document.createElement("br"), cursor);
        } else {
          el.insertBefore(document.createTextNode(ch), cursor);
        }
        i++;
        setTimeout(step, speed);
      } else {
        cursor.remove();
        resolve();
      }
    }
    step();
  });
}

async function renderWish(i, animate = true) {
  wishBusy = true;
  const total = CONFIG.wishes.length;
  const isLast = i === total - 1;

  if (animate) {
    wishCard.classList.remove("enter");
    wishCard.classList.add("leave");
    await new Promise((r) => setTimeout(r, 380));
  }
  wishCard.classList.remove("leave");
  void wishCard.offsetWidth;
  wishCard.classList.add("enter");

  wishProgressEl.textContent = `${i + 1} / ${total}`;
  await typeText(wishTextEl, CONFIG.wishes[i], isLast ? 34 : 26);

  if (isLast) {
    btnNextWish.classList.add("hidden");
    btnFinalSurprise.classList.remove("hidden");
    heartBurst(26);
    const canvas = document.createElement("canvas");
    canvas.style.position = "absolute";
    canvas.style.inset = "0";
    canvas.style.zIndex = "5";
    canvas.style.pointerEvents = "none";
    $("#screen-wishes").appendChild(canvas);
    spawnConfetti(canvas, 4000);
    setTimeout(() => canvas.remove(), 4200);
  }
  wishBusy = false;
}

enterHandlers["screen-wishes"] = () => {
  wishIndex = 0;
  btnNextWish.classList.remove("hidden");
  btnFinalSurprise.classList.add("hidden");
  renderWish(0, false);
};

btnNextWish.addEventListener("click", () => {
  if (wishBusy || wishIndex >= CONFIG.wishes.length - 1) return;
  wishIndex++;
  renderWish(wishIndex);
});

// swipe up to advance
(function attachWishSwipe() {
  const stage = $(".wishes-stage");
  let startY = 0;
  stage.addEventListener("touchstart", (e) => (startY = e.touches[0].clientY), { passive: true });
  stage.addEventListener("touchend", (e) => {
    const dy = e.changedTouches[0].clientY - startY;
    if (dy < -40 && !wishBusy && wishIndex < CONFIG.wishes.length - 1) {
      wishIndex++;
      renderWish(wishIndex);
    }
  }, { passive: true });
})();

btnFinalSurprise.addEventListener("click", () => showScreen("screen-cake"));

/* ==========================================================================
   SCREEN 6 — CAKE
   ========================================================================== */
let cakeBlown = false;
const btnBlow = $("#btnBlow");
const postBlowText = $("#postBlowText");
const confettiCanvas = $("#confettiCanvas");
const balloonsLayer = $("#balloons");

btnBlow.addEventListener("click", () => {
  if (cakeBlown) return;
  cakeBlown = true;

  $$(".candle").forEach((c) => (c.dataset.lit = "false"));
  btnBlow.classList.add("hidden");
  postBlowText.classList.remove("show");
  postBlowText.classList.remove("hidden");
  requestAnimationFrame(() => postBlowText.classList.add("show"));

  spawnConfetti(confettiCanvas, 3800);
  spawnBalloons(balloonsLayer, 9);
  heartBurst(16);

  setTimeout(() => showScreen("screen-finale"), 4600);
});

enterHandlers["screen-cake"] = () => {
  cakeBlown = false;
  $$(".candle").forEach((c) => (c.dataset.lit = "true"));
  btnBlow.classList.remove("hidden");
  postBlowText.classList.add("hidden");
  postBlowText.classList.remove("show");
  balloonsLayer.innerHTML = "";
};

/* ==========================================================================
   SCREEN 7 — FINALE
   ========================================================================== */
let finaleRun = false;
enterHandlers["screen-finale"] = () => {
  $$(".finale-line").forEach((l) => l.classList.remove("show"));
  $("#btnReplay").classList.remove("show");
  $$(".finale-line").forEach((line, i) => {
    setTimeout(() => line.classList.add("show"), 500 + i * 900);
  });
  const totalDelay = 500 + CONFIG.wishes.length * 0 + 4 * 900 + 600;
  setTimeout(() => $("#btnReplay").classList.add("show"), totalDelay);
  finaleRun = true;
};

$("#btnReplay").addEventListener("click", () => {
  location.reload();
});

/* ==========================================================================
   MUSIC PLAYER
   ========================================================================== */
$("#mpTitle").textContent = CONFIG.song.title;

const mpToggle = $("#mpToggle");
const mpIconPlay = $("#mpIconPlay");
const mpIconPause = $("#mpIconPause");
const mpProgressBar = $("#mpProgressBar");
const mpProgressFill = $("#mpProgressFill");
const mpCurrent = $("#mpCurrent");
const mpDuration = $("#mpDuration");
const mpRepeat = $("#mpRepeat");
const mpVolBtn = $("#mpVolBtn");
const mpVolume = $("#mpVolume");

function updatePlayIcon() {
  const playing = !bgMusic.paused && !bgMusic.ended;
  mpIconPlay.classList.toggle("hidden", playing);
  mpIconPause.classList.toggle("hidden", !playing);
}

mpToggle.addEventListener("click", () => {
  if (bgMusic.paused) {
    bgMusic.play().catch(() => {});
  } else {
    bgMusic.pause();
  }
  updatePlayIcon();
});

bgMusic.addEventListener("loadedmetadata", () => {
  mpDuration.textContent = fmtTime(bgMusic.duration);
});
bgMusic.addEventListener("timeupdate", () => {
  mpCurrent.textContent = fmtTime(bgMusic.currentTime);
  if (bgMusic.duration) {
    mpProgressFill.style.width = (bgMusic.currentTime / bgMusic.duration) * 100 + "%";
  }
});
bgMusic.addEventListener("play", updatePlayIcon);
bgMusic.addEventListener("pause", updatePlayIcon);

mpProgressBar.addEventListener("click", (e) => {
  if (!bgMusic.duration) return;
  const rect = mpProgressBar.getBoundingClientRect();
  const ratio = (e.clientX - rect.left) / rect.width;
  bgMusic.currentTime = ratio * bgMusic.duration;
});

mpRepeat.addEventListener("click", () => {
  bgMusic.loop = !bgMusic.loop;
  mpRepeat.classList.toggle("active", bgMusic.loop);
});
// repeat is on by default (the <audio> tag has the loop attribute)
mpRepeat.classList.add("active");

mpVolBtn.addEventListener("click", () => mpVolume.classList.toggle("hidden"));
mpVolume.addEventListener("input", (e) => {
  bgMusic.volume = parseFloat(e.target.value);
});
