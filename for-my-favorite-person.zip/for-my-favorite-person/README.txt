FOR MY FAVORITE PERSON — a romantic birthday website
======================================================

HOW TO USE
----------
1. Unzip everything, keeping the folder structure exactly as-is.
2. Open index.html on the phone (or upload the whole folder to any
   static host — Netlify, Vercel, GitHub Pages, etc. — and share the link).
3. It's built mobile-first for Android in portrait mode; that's the only
   layout it's designed for.

WHAT TO CUSTOMISE (everything is in one place: script.js, top of file)
------------------------------------------------------------------------
Open script.js and edit the CONFIG object at the very top:

  name        → her name
  usPhotos    → filenames inside images/us/    (Screen 3 slideshow)
  herPhotos   → filenames inside images/her/    (Screen 4 gallery)
  song.title  → the title shown on the music player
  wishes      → the 12 birthday messages (Screen 5) — this doubles as
                your love letter / reasons / quotes, edit freely and
                add or remove entries; the "x / total" counter updates
                itself automatically.

TO ADD YOUR PHOTOS
-------------------
Drop files into images/us/ and images/her/ using the filenames listed
in CONFIG (1.jpg, 2.jpg, ...), or use your own filenames and update the
lists in script.js to match. Until real photos are added, elegant
placeholder cards are shown instead of broken images, so the site
always looks finished.

TO CHANGE THE SONG
--------------------
Just replace music/song.mp3 with your own file, keeping the same name.
No code changes needed.

FILE MAP
--------
index.html   → structure of all 7 screens + the music player
style.css    → every color, font, and animation (see the token list at
               the top of the file if you want to shift the palette)
script.js    → CONFIG (edit this) + all interactivity
images/us/   → the "Us" slideshow photos
images/her/  → "My Favourite Girl" gallery photos
music/       → song.mp3 goes here

Built with plain HTML, CSS and JavaScript only — no frameworks, no
build step, no backend.
